import json
import base64
import os
from typing import Dict, Any

def route_message(event: Dict[str, Any], context) -> str:
    """
    Router function that receives messages from Pub/Sub and routes them
    to appropriate processing engines based on file size and region.
    
    Args:
        event: Pub/Sub event containing the message
        context: Cloud Function context
        
    Returns:
        str: Success message
    """
    
    try:
        # Decode the Pub/Sub message
        if 'data' in event:
            message_data = base64.b64decode(event['data']).decode('utf-8')
            file_info = json.loads(message_data)
        else:
            raise ValueError("No data found in Pub/Sub message")
        
        # Extract file information
        file_name = file_info.get('file_name', '')
        file_size = int(file_info.get('file_size', 0))
        region = file_info.get('region', '')
        bucket_name = file_info.get('bucket_name', '')
        
        print(f"Processing file: {file_name}, Size: {file_size} bytes, Region: {region}")
        
        # Determine processing engine based on file size
        processing_engine = determine_processing_engine(file_size)
        
        # Create routing message
        routing_message = {
            'original_message': file_info,
            'processing_engine': processing_engine,
            'routing_timestamp': context.timestamp,
            'router_region': 'northamerica-northeast1'
        }
        
        print(f"Routing to {processing_engine} engine")
        print(f"Routing message: {json.dumps(routing_message, indent=2)}")
        
        # TODO: In next steps, we'll add code to send to processing engines
        # For now, just log the routing decision
        
        return f"Successfully routed {file_name} to {processing_engine} engine"
        
    except Exception as e:
        print(f"Error in router function: {str(e)}")
        raise e

def determine_processing_engine(file_size: int) -> str:
    """
    Determine which processing engine to use based on file size.
    
    Args:
        file_size: Size of the file in bytes
        
    Returns:
        str: Processing engine name ('pandas', 'polars', or 'dask')
    """
    
    # Convert bytes to MB for easier comparison
    file_size_mb = file_size / (1024 * 1024)
    
    if file_size_mb <= 100:  # 0-100MB
        return 'pandas'
    elif file_size_mb <= 1024:  # 100MB-1GB
        return 'polars'
    else:  # 1GB+
        return 'dask'